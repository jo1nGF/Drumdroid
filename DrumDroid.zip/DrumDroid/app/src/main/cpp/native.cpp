#include <jni.h>
#include <memory>
#include <oboe/Oboe.h>
#include "engine.h"

static Engine E;
static std::shared_ptr<oboe::AudioStream> S;
struct CB : oboe::AudioStreamDataCallback {
    oboe::DataCallbackResult onAudioReady(oboe::AudioStream*, void* d, int32_t n) override {
        E.render((float*)d, n); return oboe::DataCallbackResult::Continue; }
} CBK;

#define J(r, n, ...) extern "C" JNIEXPORT r JNICALL Java_app_drumdroid_Native_##n(JNIEnv* env, jobject, ##__VA_ARGS__)
J(void, start) {
    if (S) return;
    oboe::AudioStreamBuilder b;
    b.setPerformanceMode(oboe::PerformanceMode::LowLatency)->setSharingMode(oboe::SharingMode::Exclusive)
        ->setFormat(oboe::AudioFormat::Float)->setChannelCount(2)->setDataCallback(&CBK)->openStream(S);
    if (!S) return;
    E.sr = S->getSampleRate(); S->requestStart();
}
J(void, trigger, jint p, jint v) { if ((unsigned)p < NP) E.pend[p] = v; }
J(void, setStep, jint p, jint s, jint v) { E.pat[p][s] = v; }
J(void, setBpm, jfloat b) { E.bpm = b; }
J(void, cmd, jint c) { E.cmdq = c; }
J(void, setExt, jboolean e) { E.ext = e; }
J(void, extTick) { if (E.ext) E.extN++; }
J(void, extCmd, jint c) { if (E.ext) E.cmdq = c; }
J(jint, pos) { return E.pos; }
J(jint, poll, jbyteArray a) {            // drena eventos MIDI gerados pelo sequenciador
    jbyte t[192]; int n = 0; Ev v;
    while (n < 192 && E.out.pop(v)) { t[n++] = v.s; t[n++] = v.a; t[n++] = v.b; }
    env->SetByteArrayRegion(a, 0, n, t); return n;
}
