#pragma once
#include <atomic>
#include <cstdint>
#include <math.h>

constexpr int NP = 11, NS = 16;          // pads, passos
constexpr float T2 = 6.2831853f;
// BD SD LT MT HT RS CP CH OH CC RC  (notas MIDI de bateria)
const uint8_t NOTE[NP] = {36, 38, 43, 47, 50, 37, 39, 42, 46, 49, 51};
const float LEN[NP] = {1.1f, .7f, 1.5f, 1.2f, 1.f, .1f, .6f, .35f, 1.8f, 5.f, 4.f};

struct Ev { uint8_t s, a, b; };
template <int N> struct Ring {           // fila lock-free (1 produtor, 1 consumidor)
    Ev buf[N]; std::atomic<int> w{0}, r{0};
    bool push(Ev e) { int i = w.load(std::memory_order_relaxed), n = (i + 1) % N;
        if (n == r.load(std::memory_order_acquire)) return false;
        buf[i] = e; w.store(n, std::memory_order_release); return true; }
    bool pop(Ev& e) { int i = r.load(std::memory_order_relaxed);
        if (i == w.load(std::memory_order_acquire)) return false;
        e = buf[i]; r.store((i + 1) % N, std::memory_order_release); return true; }
};

inline float ex(float t, float k) { return expf(-t / k); }
struct V { bool on = false; float t = 0, vel = 0, l1 = 0, l2 = 0; };

struct Engine {
    float sr = 48000;
    std::atomic<uint8_t> pat[NP][NS], pend[NP];
    std::atomic<float> bpm{120};
    std::atomic<int> cmdq{0}, extN{0}, pos{-1};
    std::atomic<bool> ext{false};
    Ring<256> out;                       // eventos MIDI de saída
    V vs[NP]; bool run = false; int tk = 0; float acc = 0; uint16_t offs = 0; uint32_t rng = 22222;

    float noise() { rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5; return (int32_t)rng * 4.6566129e-10f; }
    void fire(int p, int vel) { V& v = vs[p]; v = V(); v.on = true; v.vel = vel / 127.f; if (p == 7) vs[8].on = false; }  // CH corta OH

    float voice(int p, V& v) {           // vozes sintetizadas (sem samples)
        const float t = v.t, n = noise();
        switch (p) {
        case 0: return tanhf(2.2f * (sinf(T2 * (50 * t + 2.6f * (1 - ex(t, .02f)))) * ex(t, .2f) + .5f * n * ex(t, .003f)));
        case 1: v.l1 += .18f * (n - v.l1);
            return .5f * (sinf(T2 * 180 * t) * ex(t, .09f) + .6f * sinf(T2 * 330 * t) * ex(t, .06f)) + .8f * (n - v.l1) * ex(t, .13f);
        case 2: case 3: case 4: { static const float f[] = {90, 135, 200}, d[] = {.3f, .24f, .18f}; int i = p - 2;
            return sinf(T2 * (f[i] * t + f[i] * .036f * (1 - ex(t, .03f)))) * ex(t, d[i]) + .15f * n * ex(t, .004f); }
        case 5: return (.6f * sinf(T2 * 480 * t) + .4f * sinf(T2 * 1720 * t)) * ex(t, .012f) + .4f * n * ex(t, .002f);
        case 6: v.l1 += .12f * (n - v.l1); v.l2 += .35f * (n - v.l2);
            return 2.5f * (v.l2 - v.l1) * (t < .03f ? ex(fmodf(t, .01f), .003f) : ex(t - .03f, .09f));
        default: { static const float fr[] = {263, 400, 421, 474, 587, 845}, sc[] = {5, 5, 3.5f, 4}, d[] = {.04f, .3f, 1.1f, .8f};
            const int i = p - 7; float s = 0;
            for (float f : fr) s += ((int)(2 * f * sc[i] * t) & 1) ? 1.f : -1.f;
            s = s / 6 + .4f * n; v.l1 += .55f * (s - v.l1);
            return .8f * (s - v.l1) * ex(t, d[i]); }
        }
    }
    void flush() { for (int p = 0; p < NP; p++) if (offs >> p & 1) out.push({0x89, NOTE[p], 0}); offs = 0; }
    void tick() {                        // 24 PPQN; 6 ticks = 1 passo (semicolcheia)
        flush();
        if (!ext) out.push({0xF8, 0, 0});
        if (tk % 6 == 0) {
            int s = tk / 6; pos = s;
            for (int p = 0; p < NP; p++)
                if (int v = pat[p][s]) { fire(p, v); out.push({0x99, NOTE[p], (uint8_t)v}); offs |= 1 << p; }
        }
        tk = (tk + 1) % (6 * NS);
    }
    void command() {                     // 1 start, 2 stop, 3 continue
        int c = cmdq.exchange(0);
        if (c == 1 || c == 3) {
            if (c == 1) tk = 0;
            acc = 0; run = true; pos = tk / 6;
            if (!ext) out.push({(uint8_t)(c == 1 ? 0xFA : 0xFB), 0, 0});
        } else if (c == 2) { run = false; pos = -1; flush(); if (!ext) out.push({0xFC, 0, 0}); }
    }
    void render(float* o, int n) {       // chamado na thread de áudio: sem alocação, sem locks
        command();
        for (int p = 0; p < NP; p++) if (int v = pend[p].exchange(0)) fire(p, v);
        int ticks = extN.exchange(0);
        if (run && ext) while (ticks-- > 0) tick();      // sync por MIDI clock externo
        const float spt = sr * 2.5f / bpm, dt = 1 / sr;  // amostras por tick = 60/(bpm*24)*sr
        for (int i = 0; i < n; i++) {
            if (run && !ext) { if (acc <= 0) { tick(); acc += spt; } acc--; }
            float m = 0;
            for (int p = 0; p < NP; p++) {
                V& v = vs[p]; if (!v.on) continue;
                m += voice(p, v) * v.vel; v.t += dt; if (v.t > LEN[p]) v.on = false;
            }
            o[2 * i] = o[2 * i + 1] = tanhf(m * .8f);
        }
    }
};
