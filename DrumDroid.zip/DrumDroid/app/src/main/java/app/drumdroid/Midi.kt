package app.drumdroid

import android.media.midi.MidiDeviceService
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper

val NAMES = listOf("BD", "SD", "LT", "MT", "HT", "RS", "CP", "CH", "OH", "CC", "RC")
val NOTES = intArrayOf(36, 38, 43, 47, 50, 37, 39, 42, 46, 49, 51)

object Native {
    init { System.loadLibrary("drum") }
    external fun start()
    external fun trigger(pad: Int, vel: Int)
    external fun setStep(pad: Int, step: Int, vel: Int)
    external fun setBpm(bpm: Float)
    external fun cmd(c: Int)              // 1 start, 2 stop, 3 continue
    external fun setExt(on: Boolean)      // sincronizar por MIDI clock externo
    external fun extTick()
    external fun extCmd(c: Int)
    external fun pos(): Int               // passo atual, -1 = parado
    external fun poll(buf: ByteArray): Int
}

/** Ponte entre o motor de áudio e a porta de saída MIDI exposta aos outros apps. */
object MidiBridge {
    @Volatile var out: MidiReceiver? = null
    private var pump: Thread? = null
    private val h = Handler(Looper.getMainLooper())

    fun send(s: Int, a: Int = 0, b: Int = 0, len: Int = 3) {
        try { out?.send(byteArrayOf(s.toByte(), a.toByte(), b.toByte()), 0, len) } catch (e: Exception) {}
    }
    fun note(n: Int, v: Int) { send(0x99, n, v); h.postDelayed({ send(0x89, n, 0) }, 80) }

    @Synchronized fun init() {
        Native.start()
        if (pump != null) return
        pump = Thread {
            val b = ByteArray(192)
            while (true) {
                val n = Native.poll(b)
                for (i in 0 until n step 3) {
                    val s = b[i].toInt() and 0xFF
                    send(s, b[i + 1].toInt(), b[i + 2].toInt(), if (s >= 0xF8) 1 else 3)
                }
                Thread.sleep(1)
            }
        }.apply { isDaemon = true; start() }
    }
}

/** MIDI que chega de outros apps: notas disparam pads; Clock/Start/Stop sincronizam (EXT SYNC). */
object MidiIn : MidiReceiver() {
    override fun onSend(m: ByteArray, o: Int, c: Int, t: Long) {
        var i = o; val e = o + c
        while (i < e) {
            val s = m[i].toInt() and 0xFF
            when (s) { 0xF8 -> Native.extTick(); 0xFA -> Native.extCmd(1); 0xFB -> Native.extCmd(3); 0xFC -> Native.extCmd(2) }
            if ((s and 0xF0) == 0x90 && i + 2 < e && m[i + 2] > 0) {
                val p = NOTES.indexOf(m[i + 1].toInt()); if (p >= 0) Native.trigger(p, m[i + 2].toInt())
            }
            i += when { s >= 0xF8 -> 1; s >= 0xF0 -> e - i; s in 0xC0..0xDF -> 2; s >= 0x80 -> 3; else -> 1 }
        }
    }
}

class DrumMidiService : MidiDeviceService() {
    override fun onCreate() { super.onCreate(); MidiBridge.init(); MidiBridge.out = outputPortReceivers[0] }
    override fun onDestroy() { MidiBridge.out = null; super.onDestroy() }
    override fun onGetInputPortReceivers(): Array<MidiReceiver> = arrayOf(MidiIn)
}
