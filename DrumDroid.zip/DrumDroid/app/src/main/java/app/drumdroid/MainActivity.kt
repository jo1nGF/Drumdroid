package app.drumdroid

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        MidiBridge.init()
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { Surface(Modifier.fillMaxSize()) { App() } } }
    }
}

@Composable
fun App() {
    var bpm by remember { mutableFloatStateOf(120f) }
    var ext by remember { mutableStateOf(false) }
    var pos by remember { mutableIntStateOf(-1) }
    val pat = remember {
        mutableStateListOf<Boolean>().apply {
            repeat(NAMES.size * 16) { add(false) }
            // batida inicial: (pad, intervalo, deslocamento)
            listOf(Triple(0, 4, 0), Triple(1, 8, 4), Triple(7, 2, 0)).forEach { (p, k, o) ->
                for (s in o until 16 step k) { this[p * 16 + s] = true; Native.setStep(p, s, 100) }
            }
        }
    }
    LaunchedEffect(Unit) { while (true) { pos = Native.pos(); delay(16) } }
    Column(Modifier.fillMaxSize().systemBarsPadding().padding(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button({ Native.cmd(if (pos >= 0) 2 else 1) }) { Text(if (pos >= 0) "■ STOP" else "▶ PLAY") }
            Text("  BPM ${bpm.toInt()}")
            Slider(bpm, { bpm = it; Native.setBpm(it) }, Modifier.weight(1f).padding(horizontal = 12.dp), valueRange = 60f..200f)
            Text("EXT SYNC "); Switch(ext, { ext = it; Native.setExt(it) })
        }
        NAMES.forEachIndexed { p, name ->
            Row(Modifier.weight(1f)) {
                Box(Modifier.width(40.dp).fillMaxHeight().padding(1.dp).background(Color(0xFFC0392B))
                    .pointerInput(p) { detectTapGestures(onPress = { Native.trigger(p, 110); MidiBridge.note(NOTES[p], 110) }) },
                    Alignment.Center) { Text(name, fontSize = 12.sp) }
                repeat(16) { s ->
                    val on = pat[p * 16 + s]
                    Box(Modifier.weight(1f).fillMaxHeight().padding(1.dp)
                        .background(when { on -> Color(0xFFFF9800); s == pos -> Color(0xFF888888); s / 4 % 2 == 0 -> Color(0xFF3A3A3A); else -> Color(0xFF2A2A2A) })
                        .clickable { pat[p * 16 + s] = !on; Native.setStep(p, s, if (on) 0 else 100) })
                }
            }
        }
    }
}
